const fastify = require("fastify")();
const {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer,
    print,
} = require("./p4-module");

fastify.get("/cit/question", (request, reply) => {
    response = { error: "", statusCode: 200, questions: getQuestions() };

    reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(response);
});

fastify.get("/cit/answer", (request, reply) => {
  response = { error: "", statusCode: 200, answers: getAnswers() };
  
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(response);
});

fastify.get("/cit/questionanswer", (request, reply) => {
  response = { error: "", statusCode: 200, questions_answers: getQuestionsAnswers() };
  
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(response);
});

fastify.get("/cit/question/:number", (request, reply) => {
  const { number } = request.params;
  preResponse = getQuestion(number);
  response = { error: preResponse.error, statusCode: 200, question: preResponse.question, number: preResponse.number };
  
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(response);
});

fastify.get("/cit/answer/:number", (request, reply) => {
  const { number } = request.params;
  preResponse = getAnswer(number);
  response = { error: preResponse.error, statusCode: 200, answer: preResponse.answer, number: preResponse.number };
  
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(response);
});

fastify.get("/cit/questionanswer/:number", (request, reply) => {
  const { number } = request.params;
  preResponse = getQuestionAnswer(number);
  response = { error: preResponse.error, statusCode: 200, question: preResponse.question, answer: preResponse.answer, number: preResponse.number };
  
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send(response);
});

fastify.get("*", (request, reply) => {
  response = { error: "Route not found", statusCode: 404, };

  reply
  .code(200)
  .header("Content-Type", "application/json; charset=utf-8")
  .send(response);
});

const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
    if (err) {
        console.log(err);
        process.exit(1);
    }
    console.log(`Server listening on ${address}`);
});
